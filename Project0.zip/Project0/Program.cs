﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using P0Library;

namespace OfficialP0
{
    internal class Program
    {

        static void Main(string[] args)
        {
            #region A Bunch of Variables and Objects
            Security secObj = new Security();
            UserLogin newUser = new UserLogin();
            UserLogin userObj = new UserLogin();
            Accounts accObj = new Accounts(); //Calling methods only
            Accounts newAcc = new Accounts(); //Search, Add, or Update records ONLY
            Transactions newTr = new Transactions();
            Transactions trObj = new Transactions();


            #endregion

            //for (int login = 0; login < 3; login++)
            //{
            try
            {
                Console.WriteLine("********Welcome to Gringotts Wizarding Bank!**********");
                Console.WriteLine("Please select Login Type");
                Console.WriteLine("1. Gringotts Admin");
                Console.WriteLine("2. Gringotts Customer");


                int userType = Convert.ToInt32(Console.ReadLine());

                Console.Clear();
                Console.WriteLine("Enter User Name");
                string uName = Console.ReadLine();
                Console.WriteLine("Enter Password");
                string pwd = Console.ReadLine();





                if (userType == 1)
                {
                    string isValidUser = secObj.Login(uName, pwd, UserType.Admin);
                    if (isValidUser.Contains("Successful"))
                    {

                        bool stayLoggedOn = true;
                        while (stayLoggedOn == true)
                        {
                            try
                            {



                                Console.WriteLine(" Hi Administrator! Please select an option:");
                                Console.WriteLine("1. Create New Account");
                                Console.WriteLine("2. View Account Details");
                                Console.WriteLine("3. Perform Withdrawal for customer");
                                Console.WriteLine("4. Perform Deposit for account");
                                Console.WriteLine("5. Transfer Funds to Account");
                                Console.WriteLine("6. Disable customer account");
                                Console.WriteLine("7. Reactivate customer account");
                                Console.WriteLine("8. Exit");





                                int option = Convert.ToInt32(Console.ReadLine());

                                string v_username = null;
                                bool check = false;
                                int v_findAccNo = 0;
                                string v_findUser = null;



                                switch (option)
                                {
                                    case 1:
                                        Console.Clear();
                                        Console.WriteLine(" New user account or a new banking account?");
                                        Console.WriteLine("1. User");
                                        Console.WriteLine("2. Banking account");
                                        var choice = Convert.ToInt32(Console.ReadLine());
                                        if (choice == 1)
                                        {
                                            Console.WriteLine("Enter account username");
                                            newUser.userName = Console.ReadLine();
                                            Console.WriteLine("Enter customer password");
                                            newUser.userPwd = Console.ReadLine();

                                            Console.WriteLine("Enter full name");
                                            newUser.userTitle = Console.ReadLine();
                                            string cred = userObj.CreateUser(newUser);
                                            Console.WriteLine("Login created successfully!");

                                        }
                                        else if (choice == 2)
                                        {
                                            Console.WriteLine("Enter New Account Number");
                                            newAcc.accNo = Convert.ToInt32(Console.ReadLine());
                                            try
                                            {
                                                check = accObj.LocateAccount(newAcc.accNo);
                                                if (!check)
                                                {
                                                    Console.WriteLine("Please enter customer name");
                                                    newAcc.accName = Console.ReadLine();
                                                    Console.WriteLine("What will customer starting balance be?");
                                                    newAcc.accBalance = Convert.ToInt32(Console.ReadLine());
                                                    Console.WriteLine("What type of account will this be");
                                                    newAcc.accType = Console.ReadLine();
                                                    Console.WriteLine("Please enter account username");
                                                    newAcc.accUser = Console.ReadLine();
                                                    string entry = accObj.CreateAccount(newAcc);


                                                    //Console.WriteLine("Enter account username");
                                                    //newUser.userName = Console.ReadLine();
                                                    //Console.WriteLine("Enter customer password");
                                                    //newUser.userPwd = Console.ReadLine();
                                                    //string cred = userObj.CreateUser(newUser);


                                                    //string entry = accObj.CreateAccount(newAcc);
                                                    //string cred = userObj.CreateUser(newUser);
                                                    //Console.WriteLine(entry);
                                                    //Console.WriteLine(cred);
                                                }


                                                else
                                                {
                                                    Console.WriteLine("Sorry, this account number already exists");
                                                }
                                            }
                                            catch (Exception es)
                                            {
                                                Console.WriteLine(es.Message);
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine("Incorrect option!");
                                        }
                                        break;


                                    case 2:
                                        Console.Clear();
                                        Console.WriteLine("View Account Details");
                                        try
                                        {
                                            Console.WriteLine("Please enter  the account number");
                                            v_findAccNo = Convert.ToInt32(Console.ReadLine());
                                            newAcc = accObj.SearchAccNo(v_findAccNo);

                                            Console.WriteLine("Account number " + newAcc.accNo);
                                            Console.WriteLine("Account belongs to : " + newAcc.accName);
                                            Console.WriteLine("Account Type : " + newAcc.accType);
                                            Console.WriteLine("Account balance : " + newAcc.accBalance);


                                        }
                                        catch (Exception es)
                                        {
                                            Console.WriteLine(es.Message);
                                        }
                                        break;
                                    case 3:
                                        Console.Clear();
                                        Console.WriteLine("Please enter  the account number of the customer requesting withdrawal");
                                        v_findAccNo = Convert.ToInt32(Console.ReadLine());
                                        newAcc = accObj.SearchAccNo(v_findAccNo);

                                        Console.WriteLine("Your account balance is " + newAcc.accBalance);
                                        Console.WriteLine("How much will the customer's withdrawal be?");
                                        int v_withdraw = Convert.ToInt32(Console.ReadLine());
                                        newAcc.accBalance = newAcc.accBalance - v_withdraw;
                                        string postwdraw = accObj.UpdateAccBalance(newAcc);
                                        Console.WriteLine("Withdrawal accepted; Customer account balance is now " + newAcc.accBalance);





                                        break;
                                    case 4:
                                        Console.Clear();
                                        Console.WriteLine("Please enter  the account number of customer requesting deposit");
                                        v_findAccNo = Convert.ToInt32(Console.ReadLine());
                                        newAcc = accObj.SearchAccNo(v_findAccNo);

                                        Console.WriteLine("Your account balance is " + newAcc.accBalance);
                                        Console.WriteLine("How much will be deposited to this account");
                                        int v_deposit = Convert.ToInt32(Console.ReadLine());
                                        newAcc.accBalance = newAcc.accBalance + v_deposit;
                                        string postdep = accObj.UpdateAccBalance(newAcc);
                                        Console.WriteLine("Deposit accepted; Customer account balance is now " + newAcc.accBalance);

                                        break;
                                    case 5:
                                        Console.Clear();
                                        Console.WriteLine("Please enter  the account number transfer will be made from");
                                        v_findAccNo = Convert.ToInt32(Console.ReadLine());
                                        newAcc = accObj.SearchAccNo(v_findAccNo);
                                        Console.WriteLine("How much will you be transferring?");
                                        int v_transfer = Convert.ToInt32(Console.ReadLine());
                                        newAcc.accBalance = newAcc.accBalance - v_transfer;
                                        string postsend = accObj.UpdateAccBalance(newAcc);

                                        Console.WriteLine("Please enter  the account number transfer will be made to");
                                        v_findAccNo = Convert.ToInt32(Console.ReadLine());
                                        newAcc = accObj.SearchAccNo(v_findAccNo);
                                        newAcc.accBalance = newAcc.accBalance + v_transfer;
                                        string postrec = accObj.UpdateAccBalance(newAcc);
                                        Console.WriteLine("Transfer Successful");



                                        break;
                                    case 6:
                                        Console.Clear();
                                        Console.WriteLine("Disable Customer Account");
                                        Console.WriteLine("Please enter the username to be disabled ");
                                        v_findUser = Console.ReadLine();
                                        newUser = userObj.SearchUser(v_findUser);
                                        string disabled = userObj.DisableUser(newUser);
                                        Console.WriteLine("Customer account disabled!");

                                        break;
                                    case 7:
                                        Console.Clear();
                                        Console.WriteLine("Reactivate Customer Account");
                                        Console.WriteLine("Please enter the username to be reactivate ");
                                        v_findUser = Console.ReadLine();
                                        newUser = userObj.SearchUser(v_findUser);
                                        string activated = userObj.ActivateUser(newUser);
                                        Console.WriteLine("Customer account reactivated!");
                                        break;
                                    case 8:
                                        Console.Clear();
                                        Console.WriteLine("You have logged out of the Administrator account");
                                        stayLoggedOn = false;

                                        break;

                                    default:
                                        Console.Clear();
                                        Console.WriteLine("Please choose an option from our menu");
                                        break;

                                }
                                Console.ReadLine();
                                Console.Clear();

                            }
                            catch (Exception es)
                            {
                                Console.WriteLine(es.Message);
                            }

                        }
                        //break;
                    }


                    else
                    {
                        Console.WriteLine(isValidUser);

                    }

                }

                else
                {
                    string isValidUser = secObj.Login(uName, pwd, UserType.User);
                    if (isValidUser.Contains("Successful"))
                    {
                        bool stayLoggedOn = true;
                        while (stayLoggedOn == true)
                        {
                            try
                            {

                                Console.WriteLine("Welcome Customer! Please choose an option");
                                Console.WriteLine("1. Check Account Balance");
                                Console.WriteLine("2. Withdraw Funds");
                                Console.WriteLine("3. Deposit Funds");
                                Console.WriteLine("4. Transfer funds to other account");
                                Console.WriteLine("5. View Last 10 Transactions");
                                Console.WriteLine("6. Change Account Password");
                                Console.WriteLine("7. Exit");




                                //UserLogin newUser = new UserLogin();

                                int v_findAccNo = 0;
                                string v_findUser = null;
                                string v_username = null;
                                string v_newpwd = null;

                                int option = Convert.ToInt32(Console.ReadLine());
                                switch (option)
                                {
                                    case 1:
                                        Console.Clear();
                                        try
                                        {

                                            v_username = uName;

                                            List<Accounts> currentbal = accObj.ShowBalance(v_username);
                                            foreach (var item in currentbal)
                                            {
                                                Console.WriteLine("Your account number is " + item.accNo);
                                                Console.WriteLine("Your current balance is " + item.accBalance);
                                            }



                                        }
                                        catch (Exception es)
                                        {
                                            Console.WriteLine(es.Message);
                                        }
                                        break;
                                    case 2:
                                        Console.Clear();

                                        v_username = uName;
                                        Console.WriteLine("How much would you like to withdraw?");
                                        int v_withdraw = Convert.ToInt32(Console.ReadLine());
                                        string postwdraw = accObj.Withdraw(v_withdraw, v_username);
                                        Console.WriteLine("Withdrawal successful!");
                                        break;
                                    case 3:
                                        Console.Clear();
                                        v_username = uName;
                                        Console.WriteLine("How much would you like to deposit?");
                                        int v_deposit = Convert.ToInt32(Console.ReadLine());
                                        string postdep = accObj.Deposit(v_deposit, v_username);
                                        Console.WriteLine("Deposit successful!");
                                        break;
                                    case 4:
                                        Console.Clear();
                                        v_username = uName;
                                        Console.WriteLine("How much would you like to withdraw?");
                                        int v_transfer = Convert.ToInt32(Console.ReadLine());
                                        string pretransf = accObj.Withdraw(v_transfer, v_username);
                                        Console.WriteLine("What account will you be sending to");
                                        int v_sendto = Convert.ToInt32(Console.ReadLine());
                                        string posttransf = accObj.Transfer(v_transfer, v_sendto);
                                        Console.WriteLine("Your transfer is successful!");
                                        break;
                                    case 5:
                                        Console.Clear();
                                        v_username = uName;
                                        Console.WriteLine("Here are your last 10 transactions");
                                        List<Transactions> showTr = trObj.History(v_username);
                                        foreach (var item in showTr)
                                        {
                                            Console.WriteLine(item.trNo);
                                            Console.WriteLine(item.trAmount);
                                            Console.WriteLine(item.trType);
                                            Console.WriteLine(item.trDate);
                                            Console.WriteLine(item.accNo);
                                            Console.WriteLine("- - - - - - - - - - - - - - - - - - - -");
                                        }
                                        break;
                                    case 6:
                                        Console.Clear();
                                        v_username = uName;
                                        Console.WriteLine("What will your new password be?");
                                        v_newpwd = Console.ReadLine();
                                        string updatepass = userObj.ChangePassword(v_newpwd, v_username);
                                        Console.WriteLine("Updated successfully");
                                        //newpwd = userObj.UpdateUserPwd(newUser);


                                        break;
                                    case 7:
                                        Console.Clear();
                                        Console.WriteLine("*****************Thank you for being part of the Gringotts community!*****************");
                                        stayLoggedOn = false;
                                        break;

                                    default:
                                        Console.Clear();
                                        Console.WriteLine("Please choose an option from our menu");
                                        break;


                                }
                                Console.ReadLine();
                                Console.Clear();
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                            }


                        }
                        //break;
                    }
                    else
                    {
                        Console.WriteLine(isValidUser);
                    }

                }

            }
            catch (Exception es)
            {
                Console.WriteLine(es.Message);
            }
            //}

        }
    }
}
