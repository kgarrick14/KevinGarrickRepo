CREATE TABLE tbl_Admin
(
    admUser VARCHAR(20),
    admPwd VARCHAR(20),
    admStatus VARCHAR(20) DEFAULT 'Active',
    admAtt INT, 
    CONSTRAINT pk_admUser PRIMARY KEY (admUser),
    CONSTRAINT chk_admPwd CHECK(Len(admPwd) > 5),
    CONSTRAINT chk_admStatus CHECK(admStatus in ('Active', 'Blocked'))
)
INSERT INTO tbl_Admin(userName, userPwd,admAtt, admStatus) VALUES('Monitor', 'Drag0n', 0, 'Active')
SELECT * FROM tbl_Acc
SELECT * FROM tbl_User
SELECT * FROM tbl_Admin 
SELECT * FROM tbl_Transact

update tbl_Transact set accUser  = 'Hpott' WHERE accNo =1706


Select Top 10 *  from tbl_Transact where accUser = 'Rweas'

CREATE TABLE tbl_Acc
(
    accNo int,
    accBalance FLOAT,
    accType VARCHAR(20),
    accName VARCHAR(30), 
    accStatus VARCHAR(20) ,
    CONSTRAINT pk_accNo PRIMARY KEY (accNo),
    CONSTRAINT chk_accBalance CHECK(accBalance > 1000),
    CONSTRAINT chk_accType CHECK(accType in ('Checkings', 'Savings', 'Investment')),
    CONSTRAINT chk_accName CHECK(Len(accName) > 3)
)


select SERVERPROPERTY('ServerName') AS InstanceName
select TABLE_SCHEMA,TABLE_NAME,COLUMN_NAME,DATA_TYPE, CHARACTER_MAXIMUM_LENGTH from INFORMATION_SCHEMA.COLUMNS 
where table_name='tbl_Acc'


CREATE TABLE tbl_Transact
(
   trNo int primary KEY,
   trDate DATETIME,
   TramountTotal int,
   ofAcc int,

)
ALTER TABLE tbl_Acc DROP CONSTRAINT fk_accUser

SELECT * FROM tbl_Acc
SELECT * FROM tbl_User
SELECT * FROM tbl_Admin 
SELECT * FROM tbl_Transact ORDER BY trDate

CREATE TABLE tbl_Transact
(
    trNo int not null,
    trAMount int not null, 
    trType VARCHAR(20),
    trDate DATETIME, 
    accNo int NOT NULL,
    CONSTRAINT pk_trNo PRIMARY KEY (trNo),
)
insert into tbl_Transact values(3001,200,'TransferFrom','20220603',1706)
insert into tbl_Transact values(3002,200,'Withdrawal','20220604',1706)
insert into tbl_Transact values(3003,100,'Withdrawal','20220604',1706)
insert into tbl_Transact values(3004,300,'Withdrawal','20220606',1706)
insert into tbl_Transact values(3005,50,'Withdrawal','20220606',1706)
insert into tbl_Transact values(3006,150,'TransferTo','20220607',1706)
insert into tbl_Transact values(3007,500,'TransferFrom','20220608',1706)
insert into tbl_Transact values(3008, 300,'Deposit','20220609',1706)
insert into tbl_Transact values(3009,100,'Withdrawal','20220610',1706)
insert into tbl_Transact values(3010,200,'Withdrawal','20220610',1706)
