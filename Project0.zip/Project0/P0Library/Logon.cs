﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using P0Library;

namespace P0Library
{
    public class UserLogin
    {
        public string userName { get; set; }
        public string userPwd { get; set; }
        public string userStatus { get; set; }
        public int userAtt { get; set; }
        public string userTitle { get; set; }




        SqlConnection con = new SqlConnection(@"server=localhost;database=bankingDB;user id=sa;password=Strong.Pwd-123");

        //public bool UserAuthentication(string p_userName, string p_userPwd)
        //{
        //    SqlCommand cmdUserLogin = new SqlCommand("select count(*) from tbl_User where userName=@cUser and userPwd=@cPwd", con);
        //    cmdUserLogin.Parameters.AddWithValue("@cUser", p_userName);
        //    cmdUserLogin.Parameters.AddWithValue("@cPwd", p_userPwd);
        //    con.Open();
        //    int v_userquery = Convert.ToInt32(cmdUserLogin.ExecuteScalar());

        //    con.Close();
        //    if (v_userquery == 0)
        //    {
        //        return false;
        //    }
        //    return true;
        //}


        public UserLogin SearchUser(string p_userName)
        {
            SqlCommand cmdSearchUser = new SqlCommand("select * from tbl_User where userName=@cUser", con);
            cmdSearchUser.Parameters.AddWithValue("@cUser", p_userName);
            UserLogin userProfile = new UserLogin();
            con.Open();
            SqlDataReader readUser = cmdSearchUser.ExecuteReader();
            if (readUser.Read())
            {
                userProfile.userName = readUser[4].ToString();
                //userProfile.userPwd = readUser[1].ToString();
                //userProfile.userStatus = readUser[2].ToString();
                //userProfile.userAtt = (int)readUser[3];


            }
            else
            {
                readUser.Close();
                con.Close();
                throw new Exception("Account doesn't exist");
            }
            readUser.Close();
            con.Close();
            return userProfile;
        }

        public string UpdateUserPwd(UserLogin p_userObj)
        {
            SqlCommand cmdUpdateUserPwd = new SqlCommand("update tbl_User set userPwd = @cPwd where userName=@cUser", con);
            cmdUpdateUserPwd.Parameters.AddWithValue("@cUser", p_userObj.userName);
            cmdUpdateUserPwd.Parameters.AddWithValue("@cPwd", p_userObj.userPwd);

            con.Open();

            int v_uPwd = cmdUpdateUserPwd.ExecuteNonQuery();
            con.Close();

            if (v_uPwd > 0)
            {
                return "Password updated successfully!";
            }
            return "Password update unsuccessful";

        }

        public string CreateUser(UserLogin p_userObj)
        {
            SqlCommand cmdCreateUser = new SqlCommand("insert into tbl_User (userName, userPwd, userTitle) values(@cName, @cPwd, @cTitle)", con);
            cmdCreateUser.Parameters.AddWithValue("@cName", p_userObj.userName);
            cmdCreateUser.Parameters.AddWithValue("@cPwd", p_userObj.userPwd);
            cmdCreateUser.Parameters.AddWithValue("@cTitle", p_userObj.userTitle);
            con.Open();

            var recordsAffected = cmdCreateUser.ExecuteNonQuery();
            con.Close();


            return "Login Created";
        }

        public string DisableUser(UserLogin p_userObj)
        {
            SqlCommand cmdDisableUser = new SqlCommand("update tbl_User set userStatus = 'Blocked', userAtt = 0 where userName=@cName", con);
            cmdDisableUser.Parameters.AddWithValue("@cName", p_userObj.userName);
            //cmdDisableUser.Parameters.AddWithValue("@cStatus", p_userObj.userStatus);


            con.Open();

            int v_changestatus = cmdDisableUser.ExecuteNonQuery();
            con.Close();
            return "Account status updated";



        }

        public string ActivateUser(UserLogin p_userObj)
        {
            SqlCommand cmdActivateUser = new SqlCommand("update tbl_User set userStatus = 'Active', userAtt = 0 where userName=@cName", con);
            cmdActivateUser.Parameters.AddWithValue("@cName", p_userObj.userName);
            //cmdActivateUser.Parameters.AddWithValue("@cStatus", p_userObj.userStatus);


            con.Open();

            int v_changestatus = cmdActivateUser.ExecuteNonQuery();
            con.Close();
            return "Account status updated";



        }

        public string ChangePassword(string p_password, string p_userName)
        {
            SqlCommand cmdChangePassword = new SqlCommand("update tbl_User set userPwd = @change WHERE userName = @uName", con);
            cmdChangePassword.Parameters.AddWithValue("@change", p_password);
            cmdChangePassword.Parameters.AddWithValue("@uName", p_userName);

            con.Open();

            int v_newpass = cmdChangePassword.ExecuteNonQuery();
            con.Close();
            return "Password updated!";
        }

    }
}

