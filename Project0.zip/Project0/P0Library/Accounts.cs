﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using P0Library;

namespace P0Library
{
    public class Accounts
    {
        public int accNo { get; set; }
        public string accName { get; set; }
        public int accBalance { get; set; }
        public string accStatus { get; set; }
        public string accType { get; set; }
        public string accUser { get; set; }


        SqlConnection con = new SqlConnection(@"server=localhost;database=bankingDB;user id=sa;password=Strong.Pwd-123");

        Accounts(int p_accNo, string p_accName, int p_accBalance, string p_accStatus)
        {
            p_accNo = accNo;
            p_accName = accName;
            p_accBalance = accBalance;
            p_accStatus = accStatus;

        }

        public Accounts()
        {
        }

        public string CreateAccount(Accounts p_accObj)
        {
            SqlCommand cmdNewAccount = new SqlCommand("insert into tbl_Acc (accNo,accName, accBalance, accType,accUser) values(@aNo,@aName,@aBalance,@aType,@aUser)", con);
            cmdNewAccount.Parameters.AddWithValue("@aNo", p_accObj.accNo);
            cmdNewAccount.Parameters.AddWithValue("@aName", p_accObj.accName);
            cmdNewAccount.Parameters.AddWithValue("@aBalance", p_accObj.accBalance);
            cmdNewAccount.Parameters.AddWithValue("@aType", p_accObj.accType);
            cmdNewAccount.Parameters.AddWithValue("@aUser", p_accObj.accUser);




            con.Open();
            var recordsAffected = cmdNewAccount.ExecuteNonQuery();
            con.Close();
            return "Account has now been created!";
        }
        public Accounts SearchAccNo(int p_accNo)
        {
            SqlCommand cmdSearchAccNo = new SqlCommand("select * from tbl_Acc where accNo=@aNo", con);
            cmdSearchAccNo.Parameters.AddWithValue("@aNo", p_accNo);
            Accounts accDetail = new Accounts();
            con.Open();
            SqlDataReader readAcc = cmdSearchAccNo.ExecuteReader();
            if (readAcc.Read())
            {
                accDetail.accNo = (int)readAcc[0];
                accDetail.accName = readAcc[3].ToString();
                accDetail.accType = readAcc[2].ToString();
                accDetail.accBalance = (int)readAcc[1];


            }
            else
            {
                readAcc.Close();
                con.Close();
                throw new Exception("Account doesn't exist");
            }
            readAcc.Close();
            con.Close();
            return accDetail;
        }

        public bool LocateAccount(int p_accNo)
        {
            SqlCommand cmdLocate = new SqlCommand("select count(*) from tbl_Acc where accNo = @aNo", con);
            cmdLocate.Parameters.AddWithValue("@aNo", p_accNo);

            con.Open();
            int count = (int)cmdLocate.ExecuteScalar();
            con.Close();
            if (count == 1)
            {
                return true;
            }
            return false;
        }

        public string UpdateAccBalance(Accounts p_accObj)
        {
            SqlCommand cmdUpdateAccBalance = new SqlCommand("update tbl_Acc set accBalance = @aBalance where accNo=@aNo", con);
            cmdUpdateAccBalance.Parameters.AddWithValue("@aNo", p_accObj.accNo);
            cmdUpdateAccBalance.Parameters.AddWithValue("@aBalance", p_accObj.accBalance);


            con.Open();

            int v_newbal = cmdUpdateAccBalance.ExecuteNonQuery();
            con.Close();

            if (v_newbal > 0)
            {
                return "Withdrawal successful!!";
            }
            return "Issue with withdrawal";

        }
        public string UpdateAccStatus(Accounts p_accObj)
        {
            SqlCommand cmdUpdateAccBalance = new SqlCommand("update tbl_Acc set accStatus = @aStatus where accNo=@aNo", con);
            cmdUpdateAccBalance.Parameters.AddWithValue("@aNo", p_accObj.accNo);
            cmdUpdateAccBalance.Parameters.AddWithValue("@aStatus", p_accObj.accStatus);


            con.Open();

            int v_changestatus = cmdUpdateAccBalance.ExecuteNonQuery();
            con.Close();
            return "Account status updated";
        }

        public string Withdraw(int p_withdraw, string p_accUser)
        {
            SqlCommand cmdWithdraw = new SqlCommand("update tbl_Acc set accBalance = accBalance - @amount where accUser =@aUser ", con);
            cmdWithdraw.Parameters.AddWithValue("@amount", p_withdraw);
            cmdWithdraw.Parameters.AddWithValue("@aUser", p_accUser);
            con.Open();
            cmdWithdraw.ExecuteNonQuery();
            con.Close();
            if (p_withdraw <= 0)
            {
                throw new Exception("Must meet minimum withdrawal ");
            }
            //if (p_withdraw > accBalance)
            //{
            //    throw new Exception("Cannot withdraw more than total balance");
            //}
            return "Withdrawal Successful";

        }

        public string Deposit(int p_deposit, string p_accUser)
        {
            SqlCommand cmdDeposit = new SqlCommand("update tbl_Acc set accBalance = accBalance + @amount where accUser =@aUser ", con);
            cmdDeposit.Parameters.AddWithValue("@amount", p_deposit);
            cmdDeposit.Parameters.AddWithValue("@aUser", p_accUser);
            con.Open();
            cmdDeposit.ExecuteNonQuery();
            //con.Close();
            if (p_deposit < 1)
            {
                throw new Exception("Must meet minimum deposit");

            }


            con.Close();
            return "Withdrawal Successful";


        }

        public string Transfer(int p_transferto, int p_accNo)
        {
            SqlCommand cmdTo = new SqlCommand("update tbl_acc set accBalance = accBalance + @amount where accNo = @ToAccount", con);
            cmdTo.Parameters.AddWithValue("@amount", p_transferto);
            cmdTo.Parameters.AddWithValue("@ToAccount", p_accNo);
            con.Open();
            cmdTo.ExecuteNonQuery();
            con.Close();

            if (p_transferto < 1)
            {
                throw new Exception("Must meet minimum deposit");

            }



            return "Withdrawal Successful";

        }





        //public double Deposit(int d_total)
        //{
        //    if (d_total < 1)
        //    {
        //        throw new Exception("Must deposit a minimum of $1");
        //    }
        //    accBalance = accBalance + d_total;
        //    return accBalance;
        //}
        //public double Transfer(int t_sent)
        //{
        //    accBalance = accBalance - t_sent;
        //    accBalance = accBalance + t_sent;
        //    return accBalance;
        //}

        //public Accounts ShowBalance(string p_accUser)

        public List<Accounts> ShowBalance(string p_accUser)
        {
            //SqlCommand cmdShowBalance = new SqlCommand("SELECT * from tbl_Acc Join tbl_User ON tbl_Acc.accUser = tbl_User.userName", con);

            SqlCommand cmdShowBalance = new SqlCommand("SELECT accNo, accBalance from tbl_Acc Left Join tbl_User ON tbl_Acc.accUser = tbl_User.userName where accUser=@aUser", con);
            cmdShowBalance.Parameters.AddWithValue("@aUser", p_accUser);
            con.Open();
            SqlDataReader readBal = cmdShowBalance.ExecuteReader();
            List<Accounts> accBal = new List<Accounts>();
            while (readBal.Read())
            {

                accBal.Add(new Accounts()
                {
                    accNo = (int)readBal[0],
                    accBalance = (int)readBal[1]
                });
            }


            readBal.Close();
            con.Close();
            return accBal;

        }








    }


    public class Transactions
    {
        public int trNo { get; set; }
        public int trAmount { get; set; }
        public string trType { get; set; }
        public DateTime trDate { get; set; }
        public int accNo { get; set; }
        public string accUser { get; set; }




        SqlConnection con = new SqlConnection(@"server=localhost;database=bankingDB;user id=sa;password=Strong.Pwd-123");



        public List<Transactions> History(string p_accUser)
        {
            SqlCommand cmdHist = new SqlCommand(" Select Top 10 trNo, trAMount, trType, trDate, accNo from tbl_Transact where accUser = @aUser", con);
            cmdHist.Parameters.AddWithValue("@aUser", p_accUser);
            con.Open();
            SqlDataReader readHist = cmdHist.ExecuteReader();
            List<Transactions> showTr = new List<Transactions>();
            while (readHist.Read())
            {
                showTr.Add(new Transactions()
                {
                    //trNo = Convert.ToInt32(showTr[0]),
                    //trAmount = Convert.ToInt32(showTr[1]),
                    //trType = showTr[2].ToString(),
                    //trDate = Convert.ToDateTime(showTr[3]),
                    //accNo = Convert.ToInt32(showTr[4])

                    trNo = (int)readHist[0],
                    trAmount = (int)readHist[1],
                    trType = readHist[2].ToString(),
                    trDate = (DateTime)readHist[3],
                    accNo = (int)readHist[4]

                });


            }
            readHist.Close();
            con.Close();
            return showTr;

        }





        //showTr.Add(new Transactions()
        //{
        //    trNo = Convert.ToInt32(showTr[0]),
        //            trAmount = Convert.ToInt32(showTr[1]),
        //            trType = showTr[2].ToString(),
        //            trDate = Convert.ToDateTime(showTr[3]),
        //            accNo = Convert.ToInt32(showTr[4])

        //        });







        //public Transactions History(string p_accUser)
        //{
        //    SqlCommand cmdHist = new SqlCommand(" Select Top 10 * from tbl_Transact where accUser = @aUser", con);
        //    cmdHist.Parameters.AddWithValue("@aUser", p_accUser);
        //    Transactions trDetail = new Transactions();
        //    con.Open();
        //    SqlDataReader readtr = cmdHist.ExecuteReader();
        //    if (readtr.Read())
        //    {
        //        trDetail.trNo = (int)readtr[0];
        //        trDetail.trAmount = (int)readtr[1];
        //        trDetail.trType = readtr[2].ToString();
        //        trDetail.trDate = (DateTime)readtr[3];
        //        trDetail.accNo = (int)readtr[4];


        //    }
        //    else
        //    {
        //        readtr.Close();
        //        con.Close();
        //        throw new Exception("Account doesn't exist");
        //    }
        //    readtr.Close();
        //    con.Close();
        //    return trDetail;




        //}


    }
}

