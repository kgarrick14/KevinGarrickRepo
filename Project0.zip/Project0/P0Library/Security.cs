﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using P0Library;

namespace P0Library
{
    public enum UserType
    {
        Admin,
        User
    }



    public class Security
    {

        public string userName { get; set; }
        public string userPwd { get; set; }
        public string admUser { get; set; }
        public string admPwd { get; set; }
        public string userStatus { get; set; }
        public int userAtt { get; set; }



        public string Login(string userName, string userPwd, UserType p_uType)
        {
            SqlConnection con = new SqlConnection(@"server=localhost;database=bankingDB;user id=sa;password=Strong.Pwd-123;MultipleActiveResultSets=true");
            SqlCommand cmd;


            if (p_uType == UserType.Admin)
            {
                cmd = new SqlCommand("select count(*) from tbl_Admin where userName=@uName and userPwd=@pwd", con);
            }
            else
            {
                cmd = new SqlCommand("select count(*) from tbl_User where userName=@uName and userPwd=@pwd", con);
            }


            cmd.Parameters.AddWithValue("@uName", userName);
            cmd.Parameters.AddWithValue("@pwd", userPwd);


            con.Open();
            int loginResult = (int)cmd.ExecuteScalar();
            //con.Close();

            if (p_uType == UserType.User)
            {
                SqlCommand cmdAttemps = new SqlCommand("select userStatus,userAtt from tbl_User where userName=@uName", con);

                cmdAttemps.Parameters.AddWithValue("@uName", userName);
                //con.Open();

                SqlDataReader readUser = cmdAttemps.ExecuteReader();
                if (readUser.Read())
                {
                    string status = readUser[0].ToString();
                    int attemps = (int)readUser[1];
                    readUser.Close();
                    //con.Close();

                    if (status == "Blocked")
                    {
                        return "Account is Blocked, please contact Admin";
                    }
                    if (loginResult == 1 && status == "Active")
                    {
                        return "Login Successful";
                    }
                    else
                    {
                        SqlCommand updateAccount;
                        if (attemps == 3)
                        {
                            updateAccount = new SqlCommand("update tbl_User set userStatus = 'Blocked' where userName=@uName", con);
                        }
                        else
                        {
                            updateAccount = new SqlCommand("update tbl_User set userAtt=userAtt+1 where userName=@uName", con);
                        }
                        updateAccount.Parameters.AddWithValue("@uName", userName);
                        //con.Open();
                        updateAccount.ExecuteNonQuery();
                        con.Close();
                        return userName + " and password does not match";
                    }

                }
                con.Close();
                return " incorrect login";
            }
            else
            {
                if (loginResult == 1)
                {
                    return "Login Successful For Admin";
                }
                else
                {
                    return "Login Failed For Admin";
                }
            }

        }
    }
}

