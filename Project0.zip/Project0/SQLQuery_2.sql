SELECT * FROM tbl_Acc
SELECT * FROM tbl_User
SELECT * FROM tbl_Admin 
SELECT * FROM tbl_Transact
